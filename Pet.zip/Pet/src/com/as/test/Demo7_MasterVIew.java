package com.as.test;

import com.as.view.MasterView;

public class Demo7_MasterVIew {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MasterView masterView=new MasterView();
		masterView.showMenu();
	}

}
