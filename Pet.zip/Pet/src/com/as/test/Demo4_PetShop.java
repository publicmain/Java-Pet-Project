package com.as.test;

import com.as.bean.shop.PetShop;

public class Demo4_PetShop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//
		PetShop petShop=new PetShop("德龙宠物店");
		petShop.show();
	}

}
