package com.as.test;

import java.util.ArrayList;
import java.util.List;

import com.as.bean.Master;
import com.as.bean.Pet;
import com.as.util.Tools;

public class Demo1_master_实现持久化存储 {

	public static void main(String[] args) {
		
//		List<Pet> pets=new ArrayList<Pet>();
//		pets.add(new Pet("小白", 100, 50, 20, 150, 50, 56));
//		pets.add(new Pet("小黑", 130, 54, 24, 154, 54, 56));
//		pets.add(new Pet("大黄", 500, 51, 28, 152, 55, 58));
//		Master master=new Master("老李", "123abc", 5000, pets);
//		
//		//实现把master存到文件中
//		//游戏存档:实现对象能序列化,能被序列化的对象,才能实现持久化存储
//		Tools.save(master);
		
	}
}
