package com.as.test;

import com.as.bean.Pet;

public class T1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Pet pet=null;
		Pet pet1=new Pet();
		Pet pet2=new Pet();
		Pet pet3=new Pet();
		System.out.println(pet1);
		System.out.println(pet2);
		System.out.println(pet3);
		//jdk
		//jre
		//jvm
		//.java---.class--jvm--
		//
		
		
		
	}

}
